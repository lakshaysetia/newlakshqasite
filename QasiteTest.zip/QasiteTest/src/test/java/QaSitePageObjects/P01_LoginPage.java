package QaSitePageObjects;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utility.Givewait;
import utility.ReadPropertyFile;
import utility.objectActions;



public class P01_LoginPage {
WebDriver driver;
Givewait w;

objectActions oa;

	@FindBy (xpath="//*[@id='nav_login_button_holder']/div/div/div[2]/div")
	WebElement LoginButton;
	@FindBy (xpath=".//*[@id='nav_phone']")
	WebElement PhoneTextBox;
	@FindBy (xpath=".//*[@id='nav_yob']")
	WebElement YOBTextBox;
	@FindBy (xpath="//*[@id='col2alt_left']/div[1]")
	WebElement LogoutSuccessfulMessage;
	
	ReadPropertyFile RF = new ReadPropertyFile();
	
	
	
	public P01_LoginPage(WebDriver driver) throws IOException
	{System.out.println("Into P01_HomePage Constructor");
		//ReadPropertyFile RF;
		
		
		//this.browser = RF.getBrowser();
		//this.remoteUrl = RF.getremoteUrl();
		
		this.driver = driver;
		oa=new objectActions(driver);
		w=new Givewait(driver);
		w.impWait(30);
		driver.manage().window().maximize();
		driver.get(RF.getQaSiteURL());
		PageFactory.initElements(driver, this);
		//(new WebDriverWait(driver,10)).until(ExpectedConditions.visibilityOf(LoginButton));
		w.ElementLoadWait(LoginButton,30);
		System.out.println("In Constructor for P01_HomePage");
		
	}
	
	
	public boolean Login(String phno,String yob)
	{System.out.println("Into login");
		try
		{
			oa.sendText(PhoneTextBox,phno);
			oa.sendText(YOBTextBox,yob);
			oa.clickElement(LoginButton);
		}
	
	
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("No Element Found Exception");
			return false;
		} catch (AssertionError e) {
			e.printStackTrace();
			System.out.println("Assertion Error");
			return false;
		}
		System.out.println(" login successfull");
		return true;
	
}
	
	public boolean verifyLogoutSucessfull()
	{try
	{
	if(oa.verifyWebElementText(LogoutSuccessfulMessage,"You have successfully logged out. Sign-in again to see your saved offers."))
	{
		System.out.println(" logout successfull");
		return true;
	}
	else
	{System.out.println(" logout unsuccessfull");
		return false;
	}
	}
	catch (Exception e) {
		e.printStackTrace();
		System.out.println("No Element Found Exception");
		return false;
	} catch (AssertionError e) {
		e.printStackTrace();
		System.out.println("Assertion Error");
		return false;
	}
	
	
	}
	
}
