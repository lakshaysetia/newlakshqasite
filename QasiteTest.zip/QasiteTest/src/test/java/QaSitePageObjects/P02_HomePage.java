package QaSitePageObjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utility.Givewait;
import utility.ReadPropertyFile;
import utility.objectActions;

public class P02_HomePage {
	WebDriver driver;
	Givewait w;

	objectActions oa;

		
		ReadPropertyFile RF = new ReadPropertyFile();
		
		
		
		public P02_HomePage(WebDriver driver) throws IOException
		{System.out.println("Into P01_HomePage Constructor");
			//ReadPropertyFile RF;
			
			
			//this.browser = RF.getBrowser();
			//this.remoteUrl = RF.getremoteUrl();
			
			this.driver = driver;
			oa=new objectActions(driver);
			w=new Givewait(driver);
			w.impWait(30);
			driver.manage().window().maximize();
			driver.get(RF.getQaSiteURL());
			PageFactory.initElements(driver, this);
			//(new WebDriverWait(driver,10)).until(ExpectedConditions.visibilityOf(LoginButton));
			//w.ElementLoadWait(LoginButton,30);
			System.out.println("In Constructor for P01_HomePage");
			
		}
		
		
		
	}


