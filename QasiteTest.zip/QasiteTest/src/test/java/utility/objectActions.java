package utility;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class objectActions {

	WebDriver driver;
	Givewait w;
	
	
	public objectActions(WebDriver driver)
	{System.out.println("Into objectActions Constructor");
	this.driver = driver;
	w=new Givewait(driver);
		
	}
	
	public boolean clickElement(WebElement we)
	{
		System.out.println("Entered into clickElement ");
		
		try
	{w=new Givewait(driver);
		w.ElementLoadWait(we,30);
		
		we.click();
	}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("No Element Found Exception");
			return false;
		} catch (AssertionError e) {
			e.printStackTrace();
			System.out.println("Assertion Error");
			return false;
		}
		return true;
		
	}
	public boolean clickElementWithVisibleText(String ElementType,String Visibletext)   //this will click on a link which has visible text as value passed to it.
	{
		System.out.println("Entered into clickElementWithVisibleText ");
		try
		{w=new Givewait(driver);
			w.impWait(25);
			
			switch (ElementType){
		    case "LINK":         
		      driver.findElement(By.xpath("//a[contains(text(),'"+Visibletext+"')]")).click();
		         break;
		    case "DIV":
		    	driver.findElement(By.xpath("//div[contains(text(),'"+Visibletext+"')]")).click();
		        break;
		   
		    }  }         
			catch (Exception e) {
				e.printStackTrace();
				System.out.println("No Element Found Exception");
				return false;
			} catch (AssertionError e) {
				e.printStackTrace();
				System.out.println("Assertion Error");
				return false;
			}
			return true;
		
		
	}
	
	
	public boolean verifyWebElementText(WebElement element, String text) throws IOException {
		
				try {
					w.ElementLoadWait(element,30);
					
						if (element.getText().trim().equals(text)) {
							System.out.println("Executed :verifyWebElementText, PASS");
							return true;
						}
						else
						{System.out.println("element not found");
							return false;
						}
				 }         
	catch (Exception e) {
		e.printStackTrace();
		System.out.println("No Element Found Exception");
		return false;
	} catch (AssertionError e) {
		e.printStackTrace();
		System.out.println("Assertion Error");
		return false;
	}
	
	}
	public boolean selectDropdownByVisibleText(WebElement element, String text) throws IOException {
		
		try {System.out.println("into selectDropdownByVisibleText");
			w.ElementLoadWait(element,30);
			
					
						Select elementSelectObj = new Select(element);
					
							List<WebElement> AllOptions = elementSelectObj.getOptions();
							for (WebElement itr : AllOptions) {
			
								if (itr.getText().equalsIgnoreCase(text)) {
								System.out.println("Executed: selectDropdownByVisibleText, PASS");
								itr.click();
								return true;
								}
							}

						return false;
						}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("No Element Found Exception");
			return false;
		} catch (AssertionError e) {
			e.printStackTrace();
			System.out.println("Assertion Error");
			return false;
		}
		
					
				}
	
	
	public boolean sendText(WebElement element, String text) throws IOException {
		
		try
		{System.out.println("into sendText");
					w.ElementLoadWait(element, 30);
						element.clear();
						element.sendKeys(text);
						System.out.println("Executed sendText");
					return true;
					}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("No Element Found Exception");
			return false;
		} catch (AssertionError e) {
			e.printStackTrace();
			System.out.println("Assertion Error");
			return false;
		}
	}
	
	public boolean clickImage(String src)
	{
		
		try{
			System.out.println("into clickImage");
			
	w.impWait(80);
	 System.out.println("//img[@src='"+src+"']");
		
	 WebElement we=driver.findElement(By.xpath("//img[@src='"+src+"']"));
	
	 we.click();
	 
	 System.out.println("Executed clickImage");
		return true;
		}
	catch (Exception e) {
		e.printStackTrace();
		System.out.println("No Element Found Exception");
		return false;
	} catch (AssertionError e) {
		e.printStackTrace();
		System.out.println("Assertion Error");
		return false;
	}
	
}
	
	
}
