package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ReadPropertyFile {
	//static InputStream input;
	File file;
	FileInputStream fileinput;
	Properties prop;
	String rootPath;
	String envrn;

	public ReadPropertyFile() throws IOException
	{
		System.out.println("Selected Environment is:" + System.getProperty("environment"));
		System.out.println("TestPlanID is :"+System.getProperty("testPlanID"));
		System.out.println("BuildId is :"+System.getProperty("buildID"));
		
		rootPath = System.getProperty("user.dir");
		
		try
		{
			if(System.getProperty("environment").equalsIgnoreCase("http://podop.cellfire.com"))
			{
				file = new File(rootPath+"//prp//prop.properties");
			}
			else if(System.getProperty("environment").equalsIgnoreCase("http://devop.cellfire.com"))
			{
				file = new File(rootPath+"//prp//prop.properties");
			}
		}	
		catch(NullPointerException e)
		{
			file = new File(rootPath+"//prp//prop.properties");
		}
		
		fileinput = null;
		
		try
		{
			fileinput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		prop = new Properties();
		prop.load(fileinput);
		//System.out.println("url is "+prop.getProperty("opPodUrl"));
		//System.out.println("url is "+prop.getProperty("opUrl"));
		//System.out.println("buildnumber is ::::"+prop.getProperty("buildNumberRF2"));
		
	}
	
/*	public void SelectPropertyFile() throws IOException
	{
		
		rootPath = System.getProperty("user.dir");
		
		try
		{
			if(System.getProperty("environment").equalsIgnoreCase("http://podop.cellfire.com"))
			{
				file = new File(rootPath+"//prp//pod.properties");
			}
			else if(System.getProperty("environment").equalsIgnoreCase("http://devop.cellfire.com"))
			{
				file = new File(rootPath+"//prp//dev.properties");
			}
		}	
		catch(NullPointerException e)
		{
			file = new File(rootPath+"//prp//dev.properties");
		}
		
		fileinput = null;
		
		try
		{
			fileinput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		prop = new Properties();
		prop.load(fileinput);
		//System.out.println("url is "+prop.getProperty("opPodUrl"));
		System.out.println("url is "+prop.getProperty("opUrl"));
		
		
	}*/
	
	public String getQaSiteURL()
	{
		return prop.getProperty("qasiteUrl");
	}
	
	public String getQaSiteUserName()
	{
		return prop.getProperty("CSToolusername");
	}
	
	
	public String getQaSitePassword()
	{
		return prop.getProperty("CSToolpassword");
	}
	public String getTestLinkURL()
	{
		return prop.getProperty("testlinkURL");
	}
	public String getTestLinkdevKey()
	{
		return prop.getProperty("testlinkdevKey");
	}
	
	public String getPlatformName()
	{
		return prop.getProperty("platformName");
	}
	
	
	
	public void setBuildID(String buildID)
	{
		prop.setProperty("buildNumberRF2", buildID);
	}
	
	
	public int getBuildID()
	{
		String build = new String();
		build= prop.getProperty("buildNumberRF2");
		return Integer.parseInt(build);
	}
	
	public String getBuildName()
	{
		System.out.println("Inside getBuildName");
		
				
		if (System.getProperty("buildID")==null || System.getProperty("buildID")=="Auto")
		{
			System.out.println("Inside getBuildName If condition");
			return prop.getProperty("buildName");
		} else {
				
			return System.getProperty("buildID");
		}
		
	}
	
	public String getTestPlanID()
	{
		System.out.println("Inside getTestPlanID");
		
		if (System.getProperty("testPlanID")==null || System.getProperty("testPlanID")=="123")
		{
			System.out.println("Inside getTestPlanID If cn");
			return prop.getProperty("testPlanID1");
		} else {
				
			return System.getProperty("testPlanID");
		}
	}
}
		

