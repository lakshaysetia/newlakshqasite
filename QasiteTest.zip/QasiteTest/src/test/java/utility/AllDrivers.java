package utility;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;



public class AllDrivers {
	

	public WebDriver createDriver(String browser, String url) throws MalformedURLException {
			DesiredCapabilities  cap = new DesiredCapabilities();
		
		if (browser.equalsIgnoreCase("firefox")) {
			cap = DesiredCapabilities.firefox();
			cap.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
			
		} else if (browser.equalsIgnoreCase("chrome")) {
			
			cap = DesiredCapabilities.chrome();
			//System.setProperty("webdriver.chrome.driver","C:\\apps\\chromedriver.exe");  // -Dwebdriver.chrome.driver="C:\\apps\\chromedriver.exe"
			
			// 45.0.2454.93 m
			ChromeOptions options = new ChromeOptions();
			options.addArguments(Arrays.asList("--start-maximized", "allow-running-insecure-content", "ignore-certificate-errors","--disable-extensions"));
			cap.setCapability(ChromeOptions.CAPABILITY, options);
			//cap.setCapability("chrome.binary", "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe");
			cap.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		} else if (browser.equalsIgnoreCase("Safari")) {
			cap = DesiredCapabilities.safari();
		} else if ((browser.equalsIgnoreCase("ie")) || (browser.equalsIgnoreCase("internetexplorer")) || (browser.equalsIgnoreCase("internet explorer"))) {
			cap = DesiredCapabilities.internetExplorer();
		}
		cap.setJavascriptEnabled(true);
		return new RemoteWebDriver(new URL(url), cap);
	}
}