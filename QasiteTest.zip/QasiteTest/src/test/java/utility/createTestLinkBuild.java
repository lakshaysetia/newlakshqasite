package utility;
import java.net.MalformedURLException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import utility.AllDrivers;
import utility.MasterTestData;
import utility.ReadPropertyFile;
import utility.testLink;


public class createTestLinkBuild {

	ReadPropertyFile RF;
	testLink tl;
	AllDrivers AllDrv;
	MasterTestData MTD;
	
		
		@Test
		public void createNewTestLinkBuild() throws Exception 
		{
	
			String TestScript=Thread.currentThread().getStackTrace()[1].getClassName();
			
			String testLinkURL = new String();
			String devKey = new String();
			
			String testPlanString = new String();
			String buildName = new String();
			String buildNumberString = new String();
			
			int testPlanID = 45523456;
			int buildNumber;
			int testPlanNumber;
			
			testLink tl = new testLink();
			
			
			//4544 4546 4548 4550
			ReadPropertyFile RF = new ReadPropertyFile();
			
			//MasterTestData MTD = new MasterTestData(TestScript);
			
			testLinkURL = RF.getTestLinkURL();
			
			devKey = RF.getTestLinkdevKey();
			
			buildName = RF.getBuildName();
			
			
			// get the test plan id from bamboo custom build plan variable
			// read the test plan id from ReadProperty File Object
			// Then convert the test plan id from String to Integer value
			//System.out.println("h1");
			testPlanString = RF.getTestPlanID();
			
			System.out.println(testPlanString);
			testPlanNumber = Integer.parseInt(testPlanString);
			
			//testPlanNumber =1234;
			
			System.out.println("testPlanNumber:::::::::::"+testPlanNumber);
			System.out.println("testlinkURL::::::::::"+testLinkURL);
			System.out.println("testLinkDevKey:::::::::"+devKey);
			
			System.out.println("buildNumber from prperties file before we create build"+RF.getBuildID());
			
			//Create build method
			try{
				
				buildNumber = tl.createBuild(testPlanNumber, buildName,testLinkURL, devKey);
				
				System.out.println("buildName:::::::"+buildName);
				
				System.out.println("buildNumber:::::::"+buildNumber);
				
				buildNumberString = String.valueOf(buildNumber);
				
				// Set the build number into property file variable buildNumberRF2
				RF.setBuildID(buildNumberString);
				
				System.out.println("buildNumber from RF:::"+RF.getBuildID());
				
			}catch (Exception e){
				System.out.println("Could not create the build"+e.getMessage());
			}
			
			
		}
		
	@AfterClass
	public void tearDown()
	{
	//	driver.quit();
	}
	
	
}
