package utility;
import java.io.File;
import java.io.IOException;
import br.eti.kinoshita.testlinkjavaapi.TestLinkAPI;
import br.eti.kinoshita.testlinkjavaapi.constants.*;
import br.eti.kinoshita.testlinkjavaapi.constants.ExecutionStatus;
import br.eti.kinoshita.testlinkjavaapi.model.Build;
import br.eti.kinoshita.testlinkjavaapi.model.TestCase;
import br.eti.kinoshita.testlinkjavaapi.model.TestPlan;
import br.eti.kinoshita.testlinkjavaapi.util.TestLinkAPIException;
import br.eti.kinoshita.testlinkjavaapi.model.ReportTCResultResponse;
import java.net.MalformedURLException;
import java.net.URL;

public class testLink {
		
	public int createBuild(int testPlanID,String testbuildName, String Server_URL, String DevKey) throws TestLinkAPIException, MalformedURLException{
		
		
	
		Build testBuildNumber;
		String buildName = new String();
		String buildNotes = new String();
		String planName = new String();
		buildNotes = "Automation Build From Selenium1";
		
		buildName = "A-"+System.getProperty("buildID");
						
		System.out.println("from testLinkClass File::"+buildName);
		System.out.println("from testLinkClass File Server URL::"+Server_URL);
		System.out.println("from testLinkClass File DevKey::"+DevKey);
		System.out.println("from testLinkClass File testPlanID::"+testPlanID);
		System.out.println("from testLinkClass File buildName::"+buildName);
		
		TestLinkAPI api = new TestLinkAPI(new URL(Server_URL), DevKey);
		
		try{
			
			api.createBuild(testPlanID, buildName, buildNotes);
			testBuildNumber = api.getLatestBuildForTestPlan(testPlanID);
			System.out.println("TestBuildNumber"+testBuildNumber.getId());
			return testBuildNumber.getId();
		}catch(Exception e){
			System.out.println("Exception occured in createBuild method"+e.getMessage());
			return 0;
		}

	}
	
	public static double getTCIDS() {
		return TCIDS;
	}

	public static void setTCIDS(double tCIDS) {
		TCIDS = tCIDS;
	}

	static double  TCIDS;
	
	
	
	
	
	public void updateTCResult(int testCaseID, int testPlanID, String status, int buildNumber,String notes, String platformName,String Server_URL, String DevKey) throws TestLinkAPIException, MalformedURLException{
		
		TestLinkAPI api = new TestLinkAPI(new URL(Server_URL), DevKey);
		
		try{
			if (status == "PASSED"){
				api.reportTCResult(testCaseID, null, testPlanID, ExecutionStatus.PASSED, buildNumber, null, notes, null, null, null, platformName, null, null);
			}

			if (status =="FAILED"){
				api.reportTCResult(testCaseID, null, testPlanID, ExecutionStatus.FAILED, buildNumber, null, notes, null, null, null, platformName, null, null);
			}

			if (status =="BLOCKED"){
				api.reportTCResult(testCaseID, null, testPlanID, ExecutionStatus.BLOCKED, buildNumber, null, notes, null, null, null, platformName, null, null);
			}
			}catch(Exception e){
				System.out.println("Could not find the parameter"+e);}
		}
	
	public int getTestBuildNumber(int testPlanID,String Server_URL, String DevKey) throws TestLinkAPIException, MalformedURLException{
		Build testBuildNumber1;
		System.out.println("Inside Get Test Build Number");
		TestLinkAPI api = new TestLinkAPI(new URL(Server_URL), DevKey);
		testBuildNumber1 = api.getLatestBuildForTestPlan(testPlanID);
		System.out.println("Test Build Number::::"+testBuildNumber1);
		return testBuildNumber1.getId();
	}
	
	public int getTestPlanID(String testPlanName, String projectName,String Server_URL, String DevKey)throws TestLinkAPIException, MalformedURLException{
		
		int testPlanID;
		
		TestLinkAPI api = new TestLinkAPI(new URL(Server_URL), DevKey);
		
		try{
			testPlanID = api.getTestPlanByName(testPlanName, projectName).getId();
			return testPlanID;
		}catch(Exception e){
			System.out.println("Could not find the test Plane"+e);
			return 0;}
	}

	public void TestlinkUpdate(String Status,double Testcaseid) throws IOException
	{
	ReadPropertyFile RF =new ReadPropertyFile();
	//testLink tl = new testLink();
	if(Status.equalsIgnoreCase("Passed"))
	{
		
		try{
	    	int buildnumber; 
	    	buildnumber = getTestBuildNumber(Integer.parseInt(RF.getTestPlanID()), RF.getTestLinkURL(), RF.getTestLinkdevKey());
	    	//buildnumber = 519;
	    	updateTCResult((int)Testcaseid, Integer.parseInt(RF.getTestPlanID()), "PASSED", buildnumber,"AutomationResult", RF.getPlatformName(),RF.getTestLinkURL(), RF.getTestLinkdevKey());
	    	System.out.println("Testcase id passed :"+Testcaseid);
	    }catch(Exception e){
	    	System.out.println("Could not update the test case result to testlink"+e.getMessage());
	    }
	}
	else
	{
		try{
	    	int buildnumber; 
	    	buildnumber = getTestBuildNumber(Integer.parseInt(RF.getTestPlanID()), RF.getTestLinkURL(), RF.getTestLinkdevKey());
	    	
	    	updateTCResult( (int)Testcaseid, Integer.parseInt(RF.getTestPlanID()), "FAILED", buildnumber,"AutomationResult", RF.getPlatformName(),RF.getTestLinkURL(), RF.getTestLinkdevKey());
	    	System.out.println("Testcase id failed :"+Testcaseid);
	    }catch(Exception e1){
	    	System.out.println("Could not update the test case result to testlink"+e1.getMessage());
	    }
	}
	}
	
}
	
	


