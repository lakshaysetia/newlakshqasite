package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class MasterTestData {


	XSSFSheet ExcelWSheet;

	XSSFSheet AllExcelWSheet;

	XSSFWorkbook ExcelWBook;

	XSSFCell Cell;

	private static XSSFRow Row;
	String TestScript;
	String[] TestScripts;
	static int TestScriptRow=0;
	FileInputStream ExcelFile;




	public MasterTestData(String TestScript) throws Exception
	{
		///System.out.println("MasterTestData");
		this.TestScript = TestScript;
		try {

			String rootPath = System.getProperty("user.dir");
			String Path = rootPath+"\\prp\\TestData.xlsx";
			//System.out.println("MasterTestData1");
			//System.out.println(Path);
			// Open the Excel file
			ExcelFile= new FileInputStream(Path);
		//	System.out.println("MasterTestData11");
		
			// Access the required test data sheet
			ExcelWBook = new XSSFWorkbook(ExcelFile);

			//System.out.println("MasterTestData2");
			//Find the sheetname which has testcase begining with same name
			String SheetName;
			for(int i=0;i<ExcelWBook.getNumberOfSheets();i++)
			{//System.out.println("MasterTestData3");
				System.out.println("Sheet Name in WB is " +ExcelWBook.getSheetAt(i).getSheetName());
				SheetName = ExcelWBook.getSheetAt(i).getSheetName();
				if(TestScript.contains(SheetName))	
				{
					ExcelWSheet = ExcelWBook.getSheet(SheetName);
					break;
				}
			}
			//System.out.println("MasterTestData4");
		} 

		catch (Exception e){
			//System.out.println("MasterTestData5");
			throw (e);
		}



		//TestScripts = new String[ExcelWSheet.getLastRowNum()];
		for (int i=0; i<=ExcelWSheet.getLastRowNum();i++)
		{///System.out.println(i);
		//System.out.println(TestScript);
		//System.out.println(ExcelWSheet.getLastRowNum());
		//System.out.println(ExcelWSheet.getRow(i).getCell(1).getStringCellValue());
			//System.out.println("Test Script name in excel is "+ExcelWSheet.getRow(i).getCell(1).getStringCellValue());
			if (TestScript.equalsIgnoreCase(ExcelWSheet.getRow(i).getCell(1).getStringCellValue()))
			{
				TestScriptRow = i;
				System.out.println("TestScriptRow is "+TestScriptRow+" for testscript "+TestScript);
				break;
			}

		}





	}



	//This method is to set the File path and to open the Excel file, Pass Excel Path and Sheetname as Arguments to this method
	/*public static void setExcelFile(String SheetName) throws Exception {

		try {

		String rootPath = System.getProperty("user.dir");
		String Path = rootPath+"//prp//TestData.xlsx";

		// Open the Excel file
		FileInputStream ExcelFile = new FileInputStream(Path);

		// Access the required test data sheet
		ExcelWBook = new XSSFWorkbook(ExcelFile);

		ExcelWSheet = ExcelWBook.getSheet(SheetName);

		} catch (Exception e){

			throw (e);

		}

}*/


	//This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num
	/*public static String getCellData(int RowNum, int ColNum) throws Exception{

		try{

			Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);

			String CellData = Cell.getStringCellValue();

			return CellData;

			}catch (Exception e){

			return"";

			}

}*/


	public String getPhoneNo() {

		return ExcelWSheet.getRow(TestScriptRow).getCell(2).getStringCellValue();
	}


	public String getYOB() {

		return ExcelWSheet.getRow(TestScriptRow).getCell(3).getStringCellValue();
	}
	public double getTestlinkTestCaseID() {
		
		System.out.println(ExcelWSheet.getRow(TestScriptRow).getCell(56).getNumericCellValue());
		return ExcelWSheet.getRow(TestScriptRow).getCell(56).getNumericCellValue();
	}
	
	
	public void closeFile() throws IOException{

		ExcelWSheet = null;

		AllExcelWSheet = null;

		ExcelWBook = null;

		Cell = null;

		ExcelFile.close();


	}









	//This method is to write in the Excel cell, Row num and Col num are the parameters

	/*public static void setCellData(String Result,  int RowNum, int ColNum) throws Exception	{

		try{

			Row  = ExcelWSheet.getRow(RowNum);

		Cell = Row.getCell(ColNum, Row.RETURN_BLANK_AS_NULL);

		if (Cell == null) {

			Cell = Row.createCell(ColNum);

			Cell.setCellValue(Result);

			} else {

				Cell.setCellValue(Result);

			}

// Constant variables Test Data path and Test Data file name

				FileOutputStream fileOut = new FileOutputStream(Constant.Path_TestData + Constant.File_TestData);

				ExcelWBook.write(fileOut);

				fileOut.flush();

				fileOut.close();

			}catch(Exception e){

				throw (e);

		}

	}*/

}
