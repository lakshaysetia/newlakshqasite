package qasiteTest;

import java.io.IOException;
import java.net.MalformedURLException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import QaSitePageObjects.P01_LoginPage;

import utility.testLink;
import utility.ReadPropertyFile;
import utility.objectActions;
import utility.MasterTestData;
import utility.AllDrivers;
import utility.Givewait;

public class AaaRemoveAllAccounts1 {
	WebDriver driver;
	P01_LoginPage P01;
	AllDrivers AllDrv;
	MasterTestData MTD;
	String Status ="Passed";
	Givewait w;
	objectActions oa;
	
	@BeforeClass
	@Parameters({"browser","remoteUrl"})
	public void setup (@Optional("chrome") String browser, @Optional("http://localhost:4444/wd/hub") String remoteUrl) throws MalformedURLException
	{
		try{
			AllDrv = new AllDrivers();
			driver = AllDrv.createDriver(browser, remoteUrl);
		}catch (Exception e){
			e.printStackTrace();
		}

	}


	@Test
	public void Remove_All_Accounts() throws Exception 
	{
		String TestScript = Thread.currentThread().getStackTrace()[1].getClassName();

		System.out.println("Class name is " + TestScript);

		ReadPropertyFile RF = new ReadPropertyFile();

		String rootPath = System.getProperty("user.dir");



		System.out.println(Thread.currentThread().getStackTrace()[1].getClassName());

		System.out.println(Thread.currentThread().getStackTrace()[1].getMethodName());

		Reporter.log("Start Test for AaaRemoveAllAccounts1");

		System.out.println("Start Test for AaaRemoveAllAccounts1");

		MTD = new MasterTestData(TestScript);
		//System.out.println("p1");
		testLink.setTCIDS(MTD.getTestlinkTestCaseID());
		//System.out.println("p2");
		try{
			oa=new objectActions(driver);
			P01 = new P01_LoginPage(driver);
			//oa.clickElementWithVisibleText("DIV","Saved Offers");
			oa.clickImage("http://qaimages.cellfire.com/offer/36978_87.png");
			
			

		} 
		catch(AssertionError e)
		{
			Status = "Failed";
			Assert.assertTrue(false);
		}   
		catch (Exception e) {     
			Status="Failed";
			e.printStackTrace();
		}


		
		testLink t2 = new testLink();
		
		t2.TestlinkUpdate(Status, MTD.getTestlinkTestCaseID());        

		System.out.println("****End of Test Case AaaRemoveAllAccounts1********");

		Reporter.log("****End of Test Case AaaRemoveAllAccounts1********");
	}


	@AfterClass
	public void tearDown() throws IOException
	{

	//	driver.close();
		MTD.closeFile();
	
	}

}

	
	

