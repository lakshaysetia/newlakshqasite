package qasiteTest;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.net.MalformedURLException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import QaSitePageObjects.P01_LoginPage;
import utility.AllDrivers;
import utility.Givewait;
import utility.MasterTestData;
import utility.ReadPropertyFile;
import utility.objectActions;
import utility.testLink;

public class Login_230 {
	WebDriver driver;
	P01_LoginPage P01;
	AllDrivers AllDrv;
	MasterTestData MTD;
	String Status ="Passed";
	Givewait w;
	objectActions oa;
	
	@BeforeClass
	@Parameters({"browser","remoteUrl"})
	public void setup (@Optional("chrome") String browser, @Optional("http://localhost:4444/wd/hub") String remoteUrl) throws MalformedURLException
	{
		try{
			AllDrv = new AllDrivers();
			driver = AllDrv.createDriver(browser, remoteUrl);
		}catch (Exception e){
			e.printStackTrace();
		}

	}
	
	
	@Test
	public void Login_230() throws Exception 
	{
		String TestScript = Thread.currentThread().getStackTrace()[1].getClassName();

		System.out.println("Class name is " + TestScript);

		ReadPropertyFile RF = new ReadPropertyFile();

		String rootPath = System.getProperty("user.dir");



		System.out.println(Thread.currentThread().getStackTrace()[1].getClassName());

		System.out.println(Thread.currentThread().getStackTrace()[1].getMethodName());

		Reporter.log("Start Test for Login_230");

		System.out.println("Start Test for Login_230");

		MTD = new MasterTestData(TestScript);
		
		testLink.setTCIDS(MTD.getTestlinkTestCaseID());
	
		try{
			oa=new objectActions(driver);
			
			P01 = new P01_LoginPage(driver);
			
			P01.Login(MTD.getPhoneNo(), MTD.getYOB());
			
		oa.clickElementWithVisibleText("LINK","Logout");
			
		Assert.assertTrue(P01.verifyLogoutSucessfull());
			

		} 
		catch(AssertionError e)
		{
			Status = "Failed";
			Assert.assertTrue(false);
		}   
		catch (Exception e) {     
			Status="Failed";
			e.printStackTrace();
		}


		
		testLink t2 = new testLink();
		
		t2.TestlinkUpdate(Status, MTD.getTestlinkTestCaseID());        

		System.out.println("****End of Test Case Login_230********");

		Reporter.log("****End of Test Case Login_230********");
	}


	@AfterClass
	public void tearDown() throws IOException
	{

	//	driver.close();
		MTD.closeFile();
	
	}

}

	
	


